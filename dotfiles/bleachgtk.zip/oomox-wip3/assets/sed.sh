#!/bin/sh
sed -i \
         -e 's/#d5d7d7/rgb(0%,0%,0%)/g' \
         -e 's/#1b4500/rgb(100%,100%,100%)/g' \
    -e 's/#ffbedd/rgb(50%,0%,0%)/g' \
     -e 's/#0f6dd8/rgb(0%,50%,0%)/g' \
     -e 's/#ffbedd/rgb(50%,0%,50%)/g' \
     -e 's/#1b4500/rgb(0%,0%,50%)/g' \
	"$@"
